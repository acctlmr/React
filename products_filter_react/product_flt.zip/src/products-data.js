import gown from "./images/6.png";
import shirt1 from "./images/7.png";
import shirt2 from "./images/8.png";
import shirt3 from "./images/5.png";
import shirt4 from "./images/3.png";
import shirt5 from "./images/4.png";
import jewelry1 from "./images/9.png";
import jewelry2 from "./images/10.png";
import jewelry3 from "./images/11.png";
import watch1 from "./images/1.png";
import watch2 from "./images/2.png";
import watch3 from "./images/13.png";
export const products = [

    {
        id: 1,
        title: "Gown Product",
        category: "gown",
        price: 222.35,
        img:gown,
        
    },
    {
        id: 2,
        title: "Shirt Product",
        category: "shirt",
        price: 142.55,
        img:shirt1,
        
    },
    {
        id: 3,
        title: "Shirt Product",
        category: "shirt",
        price: 522.75,
        img:shirt2,
        
    },
    {
        id: 4,
        title: "Jewellery Product",
        category: "jewellery",
        price: 7522.75,
        img:jewelry1,
        
    },
     {
        id: 5,
        title: "Jewellery Product",
        category: "jewellery",
        price: 9522.25,
        img:jewelry2,
        
    },
      {
        id: 6,
        title: "Jewellery Product",
        category: "jewellery",
        price: 155000.75,
        img:jewelry3,
        
    },
       {
        id: 7,
        title: "Watch Product",
        category: "watch",
        price: 1522.75,
        img:watch1,
        
    },
       {
        id: 8,
        title: "Watch Product",
        category: "watch",
        price: 25000.75,
        img:watch2,
        
    },
         {
        id: 9,
        title: "Shirt Product",
        category: "shirt",
        price: 822.75,
        img:shirt3,
        
    },
           {
        id: 10,
        title: "Shirt Product",
        category: "shirt",
        price: 8822.75,
        img:shirt4,
        
    },
    {
        id: 11,
        title: "Shirt Product",
        category: "shirt",
        price: 5522.75,
        img:shirt5,
        
    },
             
    {
        id: 12,
        title: "Watch Product",
        category: "watch",
        price: 6522.75,
        img:watch3,
        
    },



];